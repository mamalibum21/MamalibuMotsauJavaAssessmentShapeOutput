/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mamalibumotsaujavaassessmentshapeoutput;

/**
 *
 * @author Lenovo-User
 */

public class MamalibuMotsauJavaAssessmentShapeOutput {

    public static void main(String[] args) {
       int i,j;
       int size =4;
       i=1;
       while(i<=size) {
           j=1;
           while(j<=i) {
               System.out.print("*");
           j++;
           }
           i++;
           System.out.println();
       }
    }
}
